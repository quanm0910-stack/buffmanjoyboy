package com.joyboy.buffman

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.joyboy.buffman.ui.theme.*
import com.joyboy.buffman.util.DisplayController

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BuffManJoyBoyTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = BackgroundDark
                ) {
                    BuffManScreen(this)
                }
            }
        }
    }
}

@Composable
fun BuffManScreen(activity: ComponentActivity) {
    val context = activity

    var hasPermission by remember {
        mutableStateOf(DisplayController.hasSecureSettingsPermission(context))
    }

    val (origW, origH) = remember { DisplayController.getCurrentResolution(context) }
    val origDpi = remember { DisplayController.getCurrentDensity(context) }

    var widthText by remember { mutableStateOf(origW.toString()) }
    var heightText by remember { mutableStateOf(origH.toString()) }
    var dpiText by remember { mutableStateOf(origDpi.toString()) }
    var autoDpi by remember { mutableStateOf(true) }

    var statusMessage by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }

    val presets = listOf(
        "Máy yếu / Lag" to Triple(720, 1280, 280),
        "Máy 4GB 90Hz" to Triple(720, 1600, 320),
        "Samsung A26" to Triple(720, 1600, 300),
        "HD 720p" to Triple(720, 1280, 320),
        "Full HD thấp" to Triple(1080, 1920, 400),
        "Reset mặc định" to Triple(0, 0, 0)
    )

    fun applyChanges() {
        if (!hasPermission) {
            statusMessage = "Chưa có quyền WRITE_SECURE_SETTINGS!\nHãy cấp quyền bằng ADB trước."
            isError = true
            return
        }

        val w = widthText.toIntOrNull()
        val h = heightText.toIntOrNull()
        var d = dpiText.toIntOrNull()

        if (w == null || h == null || d == null) {
            statusMessage = "Vui lòng nhập số hợp lệ"
            isError = true
            return
        }

        if (autoDpi) {
            d = DisplayController.calculateSuggestedDpi(origW, origH, origDpi, w, h)
            dpiText = d.toString()
        }

        val success = DisplayController.applyResolutionAndDensity(context, w, h, d)
        if (success) {
            statusMessage = "✅ Đã áp dụng: ${w}x${h} | DPI $d\nKhởi động lại game để thấy hiệu quả tốt nhất."
            isError = false
            Toast.makeText(context, "Buff màn thành công!", Toast.LENGTH_SHORT).show()
        } else {
            statusMessage = "❌ Không thể áp dụng. Kiểm tra quyền hoặc thử giá trị khác."
            isError = true
        }
    }

    fun resetDisplay() {
        if (!hasPermission) {
            statusMessage = "Chưa có quyền WRITE_SECURE_SETTINGS!"
            isError = true
            return
        }
        val success = DisplayController.resetToDefault(context)
        if (success) {
            widthText = origW.toString()
            heightText = origH.toString()
            dpiText = origDpi.toString()
            statusMessage = "✅ Đã reset về mặc định"
            isError = false
            Toast.makeText(context, "Đã reset màn hình", Toast.LENGTH_SHORT).show()
        } else {
            statusMessage = "❌ Reset thất bại"
            isError = true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0A0A0A), Color(0xFF1A0505), Color(0xFF0A0A0A))
                )
            )
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header / Logo area
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "⚔ JOYBOY ⚔",
            color = RedPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 4.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "BUFF MÀN",
            color = RedGlow,
            fontSize = 36.sp,
            fontWeight = FontWeight.Black,
            textAlign = TextAlign.Center
        )
        Text(
            text = "BY JOYBOY",
            color = TextWhite,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 3.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Tăng FPS • Giảm Lag • Free Fire",
            color = TextGray,
            fontSize = 13.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Permission warning
        if (!hasPermission) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF3D0A0A)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = RedPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "CẦN CẤP QUYỀN",
                            color = RedPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "App cần quyền WRITE_SECURE_SETTINGS (chỉ cấp 1 lần).\n\n" +
                                "Cách 1 - ADB (máy tính):\n" +
                                "adb shell pm grant com.joyboy.buffman android.permission.WRITE_SECURE_SETTINGS\n\n" +
                                "Cách 2 - Dùng Shizuku (không cần PC)",
                        color = TextGray,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            hasPermission = DisplayController.hasSecureSettingsPermission(context)
                            if (hasPermission) {
                                Toast.makeText(context, "Đã có quyền!", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Vẫn chưa có quyền. Hãy chạy lệnh ADB", Toast.LENGTH_LONG).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RedPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Kiểm tra lại quyền", color = Color.White)
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Current info
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Thông tin hiện tại", color = RedPrimary, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Độ phân giải: ${origW} × ${origH}", color = TextWhite, fontSize = 14.sp)
                Text("DPI hiện tại: $origDpi", color = TextWhite, fontSize = 14.sp)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Input section
        Text(
            "NHẬP ĐỘ PHÂN GIẢI MỚI",
            color = RedPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = widthText,
                onValueChange = { widthText = it.filter { c -> c.isDigit() } },
                label = { Text("Width", color = TextGray) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(1f),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = RedPrimary,
                    unfocusedBorderColor = Color(0xFF333333),
                    focusedTextColor = TextWhite,
                    unfocusedTextColor = TextWhite,
                    cursorColor = RedPrimary,
                    focusedLabelColor = RedPrimary,
                    unfocusedLabelColor = TextGray,
                    focusedContainerColor = InputBg,
                    unfocusedContainerColor = InputBg
                ),
                shape = RoundedCornerShape(10.dp)
            )
            OutlinedTextField(
                value = heightText,
                onValueChange = { heightText = it.filter { c -> c.isDigit() } },
                label = { Text("Height", color = TextGray) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(1f),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = RedPrimary,
                    unfocusedBorderColor = Color(0xFF333333),
                    focusedTextColor = TextWhite,
                    unfocusedTextColor = TextWhite,
                    cursorColor = RedPrimary,
                    focusedLabelColor = RedPrimary,
                    unfocusedLabelColor = TextGray,
                    focusedContainerColor = InputBg,
                    unfocusedContainerColor = InputBg
                ),
                shape = RoundedCornerShape(10.dp)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = dpiText,
            onValueChange = {
                dpiText = it.filter { c -> c.isDigit() }
                autoDpi = false
            },
            label = { Text("DPI", color = TextGray) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = RedPrimary,
                unfocusedBorderColor = Color(0xFF333333),
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                cursorColor = RedPrimary,
                focusedLabelColor = RedPrimary,
                unfocusedLabelColor = TextGray,
                focusedContainerColor = InputBg,
                unfocusedContainerColor = InputBg
            ),
            shape = RoundedCornerShape(10.dp),
            trailingIcon = {
                if (autoDpi) {
                    Text("AUTO", color = RedPrimary, fontSize = 12.sp, modifier = Modifier.padding(end = 8.dp))
                }
            }
        )

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp)
        ) {
            Checkbox(
                checked = autoDpi,
                onCheckedChange = { autoDpi = it },
                colors = CheckboxDefaults.colors(
                    checkedColor = RedPrimary,
                    uncheckedColor = TextGray
                )
            )
            Text("Tự tính DPI theo tỷ lệ màn", color = TextGray, fontSize = 13.sp)
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Apply button
        Button(
            onClick = { applyChanges() },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = RedPrimary),
            shape = RoundedCornerShape(14.dp),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp)
        ) {
            Text(
                "⚡ BUFF MÀN NGAY",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Reset button
        OutlinedButton(
            onClick = { resetDisplay() },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = RedPrimary),
            border = ButtonDefaults.outlinedButtonBorder.copy(
                brush = Brush.horizontalGradient(listOf(RedPrimary, RedDark))
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Refresh, contentDescription = null, tint = RedPrimary)
            Spacer(modifier = Modifier.width(8.dp))
            Text("RESET VỀ MẶC ĐỊNH", fontWeight = FontWeight.SemiBold)
        }

        // Status message
        if (statusMessage.isNotEmpty()) {
            Spacer(modifier = Modifier.height(16.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (isError) Color(0xFF3D0A0A) else Color(0xFF0A3D1A)
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(
                    statusMessage,
                    color = if (isError) Color(0xFFFF8A80) else Color(0xFF69F0AE),
                    modifier = Modifier.padding(14.dp),
                    fontSize = 13.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Quick presets
        Text(
            "THỬ NHANH",
            color = TextGray,
            fontSize = 12.sp,
            letterSpacing = 2.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        presets.chunked(2).forEach { rowPresets ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                rowPresets.forEach { (name, triple) ->
                    val (pw, ph, pd) = triple
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, Color(0xFF333333), RoundedCornerShape(10.dp))
                            .background(SurfaceDark, RoundedCornerShape(10.dp))
                            .clickable {
                                if (pw == 0) {
                                    resetDisplay()
                                } else {
                                    widthText = pw.toString()
                                    heightText = ph.toString()
                                    dpiText = pd.toString()
                                    autoDpi = false
                                }
                            }
                            .padding(vertical = 12.dp, horizontal = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            name,
                            color = if (pw == 0) RedPrimary else TextWhite,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                if (rowPresets.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Footer
        Text(
            "POWERED BY JOYBOY",
            color = Color(0xFF555555),
            fontSize = 11.sp,
            letterSpacing = 2.sp
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            "Lưu ý: Giá trị quá thấp/cao có thể làm UI lỗi.\nLuôn giữ ADB sẵn để reset nếu cần.",
            color = Color(0xFF444444),
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            lineHeight = 15.sp
        )
        Spacer(modifier = Modifier.height(20.dp))
    }
}
