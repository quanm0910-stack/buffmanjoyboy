package com.joyboy.buffman.ui.theme

import androidx.compose.ui.graphics.Color

val RedPrimary = Color(0xFFE53935)
val RedDark = Color(0xFFB71C1C)
val RedGlow = Color(0xFFFF1744)
val BackgroundDark = Color(0xFF0A0A0A)
val SurfaceDark = Color(0xFF1A1A1A)
val TextWhite = Color(0xFFFFFFFF)
val TextGray = Color(0xFFB0B0B0)
val InputBg = Color(0xFF121212)
