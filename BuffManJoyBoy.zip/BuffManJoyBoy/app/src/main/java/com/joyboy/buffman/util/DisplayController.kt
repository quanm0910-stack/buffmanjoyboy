package com.joyboy.buffman.util

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.WindowManager
import java.lang.reflect.Method

/**
 * Controller to change screen resolution & DPI without root.
 * Requires WRITE_SECURE_SETTINGS permission (grant once via ADB or Shizuku).
 *
 * Methods used (compatible with Pixels / Scalara style):
 * 1. Settings.Global / Settings.Secure forced values
 * 2. Reflection on IWindowManager (setForcedDisplaySize / setForcedDisplayDensityForUser)
 */
object DisplayController {

    fun hasSecureSettingsPermission(context: Context): Boolean {
        return context.checkCallingOrSelfPermission(
            "android.permission.WRITE_SECURE_SETTINGS"
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun getCurrentResolution(context: Context): Pair<Int, Int> {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = wm.currentWindowMetrics.bounds
            Pair(bounds.width(), bounds.height())
        } else {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            Pair(metrics.widthPixels, metrics.heightPixels)
        }
    }

    fun getCurrentDensity(context: Context): Int {
        return context.resources.displayMetrics.densityDpi
    }

    fun getPhysicalResolution(context: Context): Pair<Int, Int> {
        // Try to get original physical size if override exists
        return try {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            Pair(metrics.widthPixels, metrics.heightPixels)
        } catch (e: Exception) {
            getCurrentResolution(context)
        }
    }

    /**
     * Apply custom resolution and density.
     * Returns true if successful.
     */
    fun applyResolutionAndDensity(
        context: Context,
        width: Int,
        height: Int,
        density: Int
    ): Boolean {
        if (!hasSecureSettingsPermission(context)) return false
        if (width < 320 || height < 480 || density < 120 || density > 800) return false

        var success = false

        // Method 1: Settings.Global (works on many devices)
        try {
            Settings.Global.putString(
                context.contentResolver,
                "display_size_forced",
                "$width,$height"
            )
            success = true
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Method 2: Density via Secure / System
        try {
            Settings.Secure.putString(
                context.contentResolver,
                "display_density_forced",
                density.toString()
            )
            // Also try System for older devices
            Settings.System.putString(
                context.contentResolver,
                "display_density_forced",
                density.toString()
            )
            success = true
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Method 3: Reflection on IWindowManager (more reliable, same as adb wm)
        try {
            success = setForcedDisplaySizeViaReflection(width, height) || success
            success = setForcedDisplayDensityViaReflection(density) || success
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return success
    }

    fun resetToDefault(context: Context): Boolean {
        if (!hasSecureSettingsPermission(context)) return false

        var success = false
        try {
            Settings.Global.putString(context.contentResolver, "display_size_forced", "")
            Settings.Secure.putString(context.contentResolver, "display_density_forced", "")
            Settings.System.putString(context.contentResolver, "display_density_forced", "")
            success = true
        } catch (e: Exception) {
            e.printStackTrace()
        }

        try {
            resetForcedDisplaySizeViaReflection()
            resetForcedDisplayDensityViaReflection()
            success = true
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return success
    }

    // ========== Reflection helpers ==========

    private fun getWindowManagerService(): Any? {
        return try {
            val serviceManager = Class.forName("android.os.ServiceManager")
            val getService: Method = serviceManager.getDeclaredMethod("getService", String::class.java)
            val binder = getService.invoke(null, "window")
            val stub = Class.forName("android.view.IWindowManager\$Stub")
            val asInterface = stub.getDeclaredMethod("asInterface", android.os.IBinder::class.java)
            asInterface.invoke(null, binder)
        } catch (e: Exception) {
            null
        }
    }

    private fun setForcedDisplaySizeViaReflection(width: Int, height: Int): Boolean {
        return try {
            val iwm = getWindowManagerService() ?: return false
            val method = iwm.javaClass.getMethod(
                "setForcedDisplaySize",
                Int::class.javaPrimitiveType,
                Int::class.javaPrimitiveType,
                Int::class.javaPrimitiveType
            )
            // displayId = 0 (default display)
            method.invoke(iwm, 0, width, height)
            true
        } catch (e: Exception) {
            // Try alternative signature (some Android versions)
            try {
                val iwm = getWindowManagerService() ?: return false
                val method = iwm.javaClass.getMethod(
                    "setForcedDisplaySize",
                    Int::class.javaPrimitiveType,
                    Int::class.javaPrimitiveType
                )
                method.invoke(iwm, width, height)
                true
            } catch (e2: Exception) {
                false
            }
        }
    }

    private fun setForcedDisplayDensityViaReflection(density: Int): Boolean {
        return try {
            val iwm = getWindowManagerService() ?: return false
            // Prefer setForcedDisplayDensityForUser
            val method = iwm.javaClass.getMethod(
                "setForcedDisplayDensityForUser",
                Int::class.javaPrimitiveType,
                Int::class.javaPrimitiveType,
                Int::class.javaPrimitiveType
            )
            // displayId=0, density, userId=0
            method.invoke(iwm, 0, density, 0)
            true
        } catch (e: Exception) {
            try {
                val iwm = getWindowManagerService() ?: return false
                val method = iwm.javaClass.getMethod(
                    "setForcedDisplayDensity",
                    Int::class.javaPrimitiveType,
                    Int::class.javaPrimitiveType
                )
                method.invoke(iwm, 0, density)
                true
            } catch (e2: Exception) {
                false
            }
        }
    }

    private fun resetForcedDisplaySizeViaReflection(): Boolean {
        return try {
            val iwm = getWindowManagerService() ?: return false
            val method = iwm.javaClass.getMethod(
                "clearForcedDisplaySize",
                Int::class.javaPrimitiveType
            )
            method.invoke(iwm, 0)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun resetForcedDisplayDensityViaReflection(): Boolean {
        return try {
            val iwm = getWindowManagerService() ?: return false
            val method = iwm.javaClass.getMethod(
                "clearForcedDisplayDensityForUser",
                Int::class.javaPrimitiveType,
                Int::class.javaPrimitiveType
            )
            method.invoke(iwm, 0, 0)
            true
        } catch (e: Exception) {
            try {
                val iwm = getWindowManagerService() ?: return false
                val method = iwm.javaClass.getMethod(
                    "clearForcedDisplayDensity",
                    Int::class.javaPrimitiveType
                )
                method.invoke(iwm, 0)
                true
            } catch (e2: Exception) {
                false
            }
        }
    }

    /**
     * Calculate suggested DPI based on target resolution keeping physical size feel.
     */
    fun calculateSuggestedDpi(
        originalWidth: Int,
        originalHeight: Int,
        originalDpi: Int,
        targetWidth: Int,
        targetHeight: Int
    ): Int {
        if (originalWidth == 0 || originalHeight == 0) return originalDpi
        val scaleW = targetWidth.toFloat() / originalWidth
        val scaleH = targetHeight.toFloat() / originalHeight
        val scale = (scaleW + scaleH) / 2f
        val suggested = (originalDpi * scale).toInt()
        return suggested.coerceIn(120, 640)
    }
}
