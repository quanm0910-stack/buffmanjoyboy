# BUFF MÀN BY JOYBOY

App đổi **độ phân giải + DPI** (buff màn) dành cho Free Fire / game nặng, giao diện tông đỏ đen JOYBOY.

**Không cần root.** Chỉ cần cấp quyền `WRITE_SECURE_SETTINGS` **một lần** qua ADB hoặc Shizuku.

---

## Tính năng

- Đổi Resolution (Width × Height) + DPI
- Tự tính DPI theo tỷ lệ màn hình
- Preset nhanh: Máy yếu, 4GB 90Hz, Samsung A26…
- Nút Reset về mặc định
- Giao diện tối + đỏ neon

---

## Cách build APK

### Cách 1: Build bằng Android Studio (khuyên dùng)

1. Giải nén file zip này
2. Mở **Android Studio** → Open → chọn thư mục `BuffManJoyBoy`
3. Đợi Gradle sync xong
4. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. File APK nằm ở: `app/build/outputs/apk/debug/app-debug.apk`

### Cách 2: Build bằng GitHub Actions (không cần cài Android Studio)

1. Tạo repository mới trên GitHub
2. Upload toàn bộ nội dung thư mục `BuffManJoyBoy` lên repo
3. Tạo file `.github/workflows/build.yml` với nội dung bên dưới
4. Push code → GitHub Actions sẽ tự build APK
5. Vào tab **Actions** → download artifact APK

#### Nội dung file `.github/workflows/build.yml`:

```yaml
name: Build APK

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Grant execute permission for gradlew
        run: chmod +x gradlew || true

      - name: Build Debug APK
        run: |
          if [ -f "./gradlew" ]; then
            ./gradlew assembleDebug
          else
            # fallback nếu chưa có wrapper
            gradle assembleDebug
          fi

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: BuffMan-JoyBoy-APK
          path: app/build/outputs/apk/debug/*.apk
```

> Lưu ý: Project này dùng Gradle Kotlin DSL. Nếu GitHub Actions báo thiếu `gradlew`, bạn có thể generate wrapper bằng Android Studio trước rồi commit file `gradlew` + `gradle/wrapper/`.

### Cách 3: Dùng lệnh (máy đã cài Android SDK)

```bash
cd BuffManJoyBoy
# Nếu chưa có gradlew:
gradle wrapper
./gradlew assembleDebug
```

---

## Cấp quyền WRITE_SECURE_SETTINGS (bắt buộc)

Sau khi cài APK, mở app sẽ báo thiếu quyền. Làm theo một trong hai cách:

### Cách A – Dùng máy tính (ADB)

1. Bật **Developer options** + **USB debugging** trên điện thoại
2. Kết nối USB với máy tính
3. Chạy lệnh:

```bash
adb shell pm grant com.joyboy.buffman android.permission.WRITE_SECURE_SETTINGS
```

4. Mở lại app → bấm **Kiểm tra lại quyền**

### Cách B – Dùng Shizuku (không cần máy tính)

1. Cài app **Shizuku** từ Play Store
2. Khởi động Shizuku (theo hướng dẫn trong app)
3. Cấp quyền cho app Buff Màn (nếu app hỗ trợ Shizuku – hiện tại dùng ADB là chính)

---

## Reset nếu màn hình bị lỗi

Nếu đặt resolution quá thấp/cao làm UI lỗi, kết nối ADB và chạy:

```bash
adb shell wm size reset
adb shell wm density reset
```

Hoặc trong app bấm nút **RESET VỀ MẶC ĐỊNH**.

---

## Package name

`com.joyboy.buffman`

---

## Lưu ý

- Chỉ dùng cho mục đích tối ưu hiệu năng game (giảm resolution để tăng FPS).
- Giá trị DPI khuyến nghị an toàn: **200 – 640**.
- Một số máy (Samsung One UI, Xiaomi HyperOS…) có thể cần thêm bước hoặc restart.
- App này không liên quan đến hack game, chỉ thay đổi hiển thị hệ thống.

---

**POWERED BY JOYBOY**
